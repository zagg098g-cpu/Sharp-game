const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function validProfilePayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 1000);
  return {
    userId: uid,
    displayName: "QuickPlayer",
    coins: 500,
    xp: 0,
    gamesPlayed: 0,
    bestScore: 0,
    streakDays: 1,
    lastDailyClaimDate: "",
    claimedMilestones: [],
    preferredLang: "en",
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

test("Unauthenticated user cannot read or write any collection", async () => {
  const unauth = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauth.collection("users").doc(ALICE_UID).get());
  await assertFails(unauth.collection("users").doc(ALICE_UID).set(validProfilePayload(ALICE_UID)));
  await assertFails(
    unauth.collection("leaderboard").where("totalScore", ">=", 0).orderBy("totalScore", "desc").limit(20).get()
  );
  await assertFails(unauth.collection("users").doc(ALICE_UID).collection("sessions").get());
});

test("User profile create, action-based updates, and cross-user isolation", async () => {
  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bob = testEnv.authenticatedContext(BOB_UID).firestore();

  // Valid create (no @DocumentId `id` field)
  await assertSucceeds(alice.collection("users").doc(ALICE_UID).set(validProfilePayload(ALICE_UID)));

  // Reject ghost field / id field
  await assertFails(
    bob.collection("users").doc(BOB_UID).set(validProfilePayload(BOB_UID, { id: BOB_UID }))
  );

  // Reject userId spoofing
  await assertFails(
    bob.collection("users").doc(BOB_UID).set(validProfilePayload(ALICE_UID))
  );

  // Reject cross-user read & write
  await assertFails(bob.collection("users").doc(ALICE_UID).get());
  await assertFails(
    bob.collection("users").doc(ALICE_UID).update({
      coins: 999999,
      xp: 999999,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Valid action-based partial update: Complete mini-game
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).update({
      coins: 620,
      xp: 120,
      gamesPlayed: 1,
      bestScore: 340,
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Valid action-based partial update: Daily claim
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).update({
      coins: 720,
      xp: 170,
      streakDays: 2,
      lastDailyClaimDate: "2026-11-17",
      updatedAt: new Date(Date.now() - 300),
    })
  );

  // Valid action-based partial update: Language switch
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).update({
      displayName: "QuickChampion",
      preferredLang: "bn",
      updatedAt: new Date(Date.now() - 200),
    })
  );

  // Reject immutable createdAt mutation
  await assertFails(
    alice.collection("users").doc(ALICE_UID).update({
      createdAt: new Date(Date.now() - 100),
      updatedAt: new Date(Date.now() - 100),
    })
  );

  // Reject future timestamp
  await assertFails(
    alice.collection("users").doc(ALICE_UID).update({
      coins: 800,
      xp: 200,
      updatedAt: new Date(Date.now() + 60000),
    })
  );

  // Reject negative coins
  await assertFails(
    alice.collection("users").doc(ALICE_UID).update({
      coins: -10,
      xp: 200,
      updatedAt: new Date(Date.now() - 100),
    })
  );
});

test("Game sessions subcollection rules and query parity", async () => {
  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bob = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 1000);

  // Valid create
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).collection("sessions").doc("sess_1").set({
      userId: ALICE_UID,
      gameId: "reflex_tap",
      gameTitle: "Neon Reflex Tap",
      score: 420,
      coinsEarned: 85,
      xpEarned: 60,
      createdAt: now,
    })
  );

  // Reject invalid gameId
  await assertFails(
    alice.collection("users").doc(ALICE_UID).collection("sessions").doc("sess_bad").set({
      userId: ALICE_UID,
      gameId: "unknown_game",
      gameTitle: "Invalid",
      score: 10,
      coinsEarned: 5,
      xpEarned: 5,
      createdAt: now,
    })
  );

  // Reject update (immutable)
  await assertFails(
    alice.collection("users").doc(ALICE_UID).collection("sessions").doc("sess_1").update({
      score: 9999,
    })
  );

  // Owner list query succeeds (even with orderBy/limit)
  await assertSucceeds(
    alice.collection("users").doc(ALICE_UID).collection("sessions")
      .orderBy("createdAt", "desc").limit(20).get()
  );

  // Cross-user list fails
  await assertFails(
    bob.collection("users").doc(ALICE_UID).collection("sessions").get()
  );
});

test("Leaderboard public read/query parity and owner-only write", async () => {
  const alice = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bob = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date(Date.now() - 1000);

  await assertSucceeds(
    alice.collection("leaderboard").doc(ALICE_UID).set({
      userId: ALICE_UID,
      displayName: "Alice",
      totalScore: 500,
      coins: 1200,
      tier: "Silver",
      updatedAt: now,
    })
  );

  // Reject PII ghost field
  await assertFails(
    bob.collection("leaderboard").doc(BOB_UID).set({
      userId: BOB_UID,
      displayName: "Bob",
      email: "bob@example.com",
      totalScore: 100,
      coins: 500,
      tier: "Bronze",
      updatedAt: now,
    })
  );

  // Reject cross-user overwrite
  await assertFails(
    bob.collection("leaderboard").doc(ALICE_UID).update({
      totalScore: 0,
      updatedAt: now,
    })
  );

  // Signed-in user can execute exact Kotlin leaderboard query
  await assertSucceeds(
    bob.collection("leaderboard")
      .where("totalScore", ">=", 0)
      .orderBy("totalScore", "desc")
      .limit(20)
      .get()
  );
});
