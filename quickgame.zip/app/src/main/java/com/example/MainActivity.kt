package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.auth.AuthScreen
import com.example.auth.authStateFlow
import com.example.auth.signOut
import com.example.data.QuickGameRepository
import com.example.model.MiniGameId
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.QuickGameTopBar
import com.example.ui.screens.ArenaScreen
import com.example.ui.screens.GamesHubScreen
import com.example.ui.screens.MemberCenterScreen
import com.example.ui.screens.MiniGamePlayScreen
import com.example.ui.screens.RewardsLeaderboardScreen
import com.example.ui.theme.ArcadeBg
import com.example.ui.theme.ArcadeSurface
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.QuickGameTheme
import com.example.ui.theme.QuickStrings
import com.example.viewmodel.QuickGameViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

private data class NavTab(
  val route: String,
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
)

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
    )
    setContent {
      QuickGameTheme {
        AppNavigation()
      }
    }
  }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
  val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
  val user = currentUser
  if (user == null) {
    AuthScreen(onAuthSuccess = {})
  } else {
    val uid = user.uid
    val defaultName = user.displayName?.takeIf { it.isNotBlank() } ?: "QuickPlayer"
    key(uid) {
      QuickGameAuthenticatedRoot(
        currentUserId = uid,
        initialDisplayName = defaultName,
      )
    }
  }
}

@Composable
private fun QuickGameAuthenticatedRoot(
  currentUserId: String,
  initialDisplayName: String,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  val viewModel: QuickGameViewModel = viewModel(
    key = currentUserId,
    factory = viewModelFactory {
      initializer {
        val app = checkNotNull(this[APPLICATION_KEY]) {
          "APPLICATION_KEY missing from CreationExtras"
        }
        val databaseId = app.getString(R.string.firestore_database_id)
        val db = FirebaseFirestore.getInstance(databaseId)
        QuickGameViewModel(
          repository = QuickGameRepository(db),
          currentUserId = currentUserId,
          initialDisplayName = initialDisplayName,
        )
      }
    },
  )

  val profileState by viewModel.profileState.collectAsStateWithLifecycle()
  val sessionsState by viewModel.sessionsState.collectAsStateWithLifecycle()
  val leaderboardState by viewModel.leaderboardState.collectAsStateWithLifecycle()
  val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

  val snackbarHostState = remember { SnackbarHostState() }
  LaunchedEffect(toastMessage) {
    val msg = toastMessage ?: return@LaunchedEffect
    snackbarHostState.showSnackbar(msg)
    viewModel.clearToast()
  }

  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route ?: "arena"
  val isPlayRoute = currentRoute.startsWith("play/")

  val profile = (profileState as? UiState.Success)?.data ?: UserProfile(
    userId = currentUserId,
    displayName = initialDisplayName,
  )
  val strings = remember(profile.preferredLang) {
    QuickStrings(isBangla = profile.preferredLang == "bn")
  }

  val tabs = remember(strings) {
    listOf(
      NavTab("arena", strings.navArena, Icons.Rounded.Home, Icons.Outlined.Home),
      NavTab("games", strings.navGames, Icons.Rounded.SportsEsports, Icons.Outlined.SportsEsports),
      NavTab("rewards", strings.navRewards, Icons.Rounded.EmojiEvents, Icons.Outlined.EmojiEvents),
      NavTab("profile", strings.navMember, Icons.Rounded.Person, Icons.Outlined.Person),
    )
  }

  val navigateToTab: (String) -> Unit = { route ->
    navController.navigate(route) {
      popUpTo(navController.graph.findStartDestination().id) {
        saveState = true
      }
      launchSingleTop = true
      restoreState = true
    }
  }

  val launchGame: (MiniGameId) -> Unit = { game ->
    navController.navigate("play/${game.id}") {
      launchSingleTop = true
    }
  }

  BoxWithConstraints(
    modifier = Modifier
      .fillMaxSize()
      .background(ArcadeBg),
  ) {
    val useNavigationRail = maxWidth >= 600.dp

    Row(modifier = Modifier.fillMaxSize()) {
      if (useNavigationRail && !isPlayRoute) {
        NavigationRail(
          containerColor = ArcadeSurface,
          modifier = Modifier.fillMaxHeight(),
        ) {
          tabs.forEach { tab ->
            val selected = currentRoute == tab.route
            NavigationRailItem(
              selected = selected,
              onClick = { navigateToTab(tab.route) },
              icon = {
                Icon(
                  imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                  contentDescription = tab.label,
                )
              },
              label = { Text(tab.label) },
              colors = NavigationRailItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                selectedTextColor = EmeraldAccent,
                indicatorColor = EmeraldAccent,
                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
              ),
              modifier = Modifier.testTag("nav_${tab.route}"),
            )
          }
        }
      }

      Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
          if (!useNavigationRail && !isPlayRoute) {
            NavigationBar(
              containerColor = ArcadeSurface,
            ) {
              tabs.forEach { tab ->
                val selected = currentRoute == tab.route
                NavigationBarItem(
                  selected = selected,
                  onClick = { navigateToTab(tab.route) },
                  icon = {
                    Icon(
                      imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                      contentDescription = tab.label,
                    )
                  },
                  label = { Text(tab.label) },
                  colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                    selectedTextColor = EmeraldAccent,
                    indicatorColor = EmeraldAccent,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                  ),
                  modifier = Modifier.testTag("nav_${tab.route}"),
                )
              }
            }
          }
        },
      ) { innerPadding ->
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        ) {
          if (!isPlayRoute) {
            QuickGameTopBar(
              coins = profile.coins,
              streakDays = profile.streakDays,
              isBangla = strings.isBangla,
              onToggleLanguage = { viewModel.toggleLanguage() },
            )
          }

          Box(
            modifier = Modifier
              .weight(1f)
              .fillMaxSize(),
            contentAlignment = Alignment.TopCenter,
          ) {
            when (val pState = profileState) {
              is UiState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                  CircularProgressIndicator(color = EmeraldAccent)
                }
              }
              is UiState.Error -> {
                Box(
                  modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                  contentAlignment = Alignment.Center,
                ) {
                  Text(
                    text = pState.message,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyLarge,
                  )
                }
              }
              is UiState.Success -> {
                val activeProfile = pState.data
                val contentModifier = Modifier
                  .fillMaxSize()
                  .widthIn(max = 720.dp)

                Box(modifier = contentModifier) {
                  NavHost(
                    navController = navController,
                    startDestination = "arena",
                  ) {
                    composable("arena") {
                      ArenaScreen(
                        profile = activeProfile,
                        todayKey = viewModel.todayDateKey(),
                        strings = strings,
                        onPlayGame = launchGame,
                        onClaimDaily = { viewModel.claimDailyBonus() },
                        onSpinWon = { won -> viewModel.spinLuckyWheel(rewardCoins = won) },
                        onViewAllGames = { navigateToTab("games") },
                      )
                    }
                    composable("games") {
                      GamesHubScreen(
                        strings = strings,
                        onPlayGame = launchGame,
                      )
                    }
                    composable("rewards") {
                      RewardsLeaderboardScreen(
                        profile = activeProfile,
                        currentUserId = currentUserId,
                        leaderboardState = leaderboardState,
                        strings = strings,
                        onClaimMilestone = { quest -> viewModel.claimMilestone(quest) },
                      )
                    }
                    composable("profile") {
                      MemberCenterScreen(
                        profile = activeProfile,
                        sessionsState = sessionsState,
                        strings = strings,
                        onUpdateDisplayName = { newName -> viewModel.updateDisplayName(newName) },
                        onToggleLanguage = { viewModel.toggleLanguage() },
                        onSignOut = {
                          signOut(
                            credentialManager = credentialManager,
                            scope = scope,
                          )
                        },
                      )
                    }
                    composable(
                      route = "play/{gameId}",
                      arguments = listOf(navArgument("gameId") { type = NavType.StringType }),
                    ) { backStack ->
                      val gameIdRaw = backStack.arguments?.getString("gameId") ?: MiniGameId.REFLEX_TAP.id
                      val game = MiniGameId.fromId(gameIdRaw)
                      MiniGamePlayScreen(
                        game = game,
                        isBangla = strings.isBangla,
                        onRoundComplete = { score, coinsEarned, xpEarned ->
                          viewModel.recordGameResult(game, score, coinsEarned, xpEarned)
                        },
                        onBack = { navController.popBackStack() },
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
