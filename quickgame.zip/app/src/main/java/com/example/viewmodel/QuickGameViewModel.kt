package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.QuickGameRepository
import com.example.model.GameSession
import com.example.model.LeaderboardEntry
import com.example.model.MiniGameId
import com.example.model.QuestMilestone
import com.example.model.UiState
import com.example.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class QuickGameViewModel(
  private val repository: QuickGameRepository,
  private val currentUserId: String,
  private val initialDisplayName: String,
) : ViewModel() {

  private val _toastMessage = MutableStateFlow<String?>(null)
  val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

  private val _isActionBusy = MutableStateFlow(false)
  val isActionBusy: StateFlow<Boolean> = _isActionBusy.asStateFlow()

  val profileState: StateFlow<UiState<UserProfile>> =
    repository.observeUserProfile(currentUserId)
      .map<UserProfile?, UiState<UserProfile>> { profile ->
        if (profile != null) UiState.Success(profile) else UiState.Loading
      }
      .catch { error ->
        val firestoreError = unwrapFirestoreException(error)
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing profile", rootError)
        emit(UiState.Error(rootError.message ?: "Failed to load profile"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  val sessionsState: StateFlow<UiState<List<GameSession>>> =
    repository.observeRecentSessions(currentUserId)
      .map<List<GameSession>, UiState<List<GameSession>>> { UiState.Success(it) }
      .catch { error ->
        val firestoreError = unwrapFirestoreException(error)
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing sessions", rootError)
        emit(UiState.Error(rootError.message ?: "Failed to load activity"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  val leaderboardState: StateFlow<UiState<List<LeaderboardEntry>>> =
    repository.observeLeaderboard()
      .map<List<LeaderboardEntry>, UiState<List<LeaderboardEntry>>> { UiState.Success(it) }
      .catch { error ->
        val firestoreError = unwrapFirestoreException(error)
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing leaderboard", rootError)
        emit(UiState.Error(rootError.message ?: "Failed to load leaderboard"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
        initialValue = UiState.Loading,
      )

  init {
    viewModelScope.launch {
      repository.ensureUserProfile(currentUserId, initialDisplayName)
        .onFailure { e ->
          _toastMessage.value = e.localizedMessage ?: "Failed to initialize profile"
        }
    }
  }

  fun todayDateKey(): String {
    val formatter = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return formatter.format(Date())
  }

  fun clearToast() {
    _toastMessage.value = null
  }

  fun recordGameResult(
    game: MiniGameId,
    score: Long,
    coinsEarned: Long,
    xpEarned: Long,
  ) {
    val profile = (profileState.value as? UiState.Success)?.data ?: return
    viewModelScope.launch {
      _isActionBusy.value = true
      repository.recordGameResult(currentUserId, profile, game, score, coinsEarned, xpEarned)
        .onSuccess {
          _toastMessage.value = "+$coinsEarned QuickCoins • +$xpEarned XP saved!"
        }
        .onFailure { e ->
          _toastMessage.value = e.localizedMessage ?: "Failed to save score"
        }
      _isActionBusy.value = false
    }
  }

  fun claimDailyBonus() {
    val profile = (profileState.value as? UiState.Success)?.data ?: return
    val today = todayDateKey()
    if (profile.lastDailyClaimDate == today) {
      _toastMessage.value = "Daily bonus already claimed today!"
      return
    }
    viewModelScope.launch {
      _isActionBusy.value = true
      repository.claimDailyBonus(currentUserId, profile, today)
        .onSuccess { bonus ->
          _toastMessage.value = "Daily Streak Claimed: +$bonus QuickCoins!"
        }
        .onFailure { e ->
          _toastMessage.value = e.localizedMessage ?: "Failed to claim bonus"
        }
      _isActionBusy.value = false
    }
  }

  fun spinLuckyWheel(costCoins: Long = 25L, rewardCoins: Long) {
    val profile = (profileState.value as? UiState.Success)?.data ?: return
    if (profile.coins < costCoins) {
      _toastMessage.value = "Need $costCoins QuickCoins to spin!"
      return
    }
    viewModelScope.launch {
      _isActionBusy.value = true
      repository.spinLuckyWheel(currentUserId, profile, costCoins, rewardCoins)
        .onSuccess { won ->
          _toastMessage.value = "Lucky Spin won +$won QuickCoins!"
        }
        .onFailure { e ->
          _toastMessage.value = e.localizedMessage ?: "Spin sync failed"
        }
      _isActionBusy.value = false
    }
  }

  fun claimMilestone(milestone: QuestMilestone) {
    val profile = (profileState.value as? UiState.Success)?.data ?: return
    viewModelScope.launch {
      _isActionBusy.value = true
      repository.claimMilestone(currentUserId, profile, milestone)
        .onSuccess {
          _toastMessage.value = "Quest '${milestone.titleEn}': +${milestone.coinReward} QuickCoins!"
        }
        .onFailure { e ->
          _toastMessage.value = e.localizedMessage ?: "Failed to claim quest"
        }
      _isActionBusy.value = false
    }
  }

  fun updateDisplayName(newName: String) {
    val profile = (profileState.value as? UiState.Success)?.data ?: return
    val trimmed = newName.trim()
    if (trimmed.isEmpty()) {
      _toastMessage.value = "Display name cannot be empty"
      return
    }
    viewModelScope.launch {
      _isActionBusy.value = true
      repository.updateProfileSettings(currentUserId, trimmed, profile.preferredLang, profile)
        .onSuccess {
          _toastMessage.value = "Nickname updated!"
        }
        .onFailure { e ->
          _toastMessage.value = e.localizedMessage ?: "Failed to update nickname"
        }
      _isActionBusy.value = false
    }
  }

  fun toggleLanguage() {
    val profile = (profileState.value as? UiState.Success)?.data ?: return
    val nextLang = if (profile.preferredLang == "bn") "en" else "bn"
    viewModelScope.launch {
      repository.updateProfileSettings(currentUserId, profile.displayName, nextLang, profile)
        .onFailure { e ->
          _toastMessage.value = e.localizedMessage ?: "Failed to switch language"
        }
    }
  }

  private fun unwrapFirestoreException(error: Throwable): FirebaseFirestoreException? =
    generateSequence(error) { it.cause }
      .filterIsInstance<FirebaseFirestoreException>()
      .firstOrNull()

  private companion object {
    const val TAG = "QuickGameVM"
    const val STOP_TIMEOUT_MILLIS = 5000L
  }
}
