package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.MilitaryTech
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.LeaderboardEntry
import com.example.model.QuestMilestone
import com.example.model.QuickGameMilestones
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.VipTierBadge
import com.example.ui.theme.ArcadeSurfaceBorder
import com.example.ui.theme.ArcadeSurfaceElevated
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.GoldCoin
import com.example.ui.theme.GoldWarm
import com.example.ui.theme.QuickStrings
import java.text.NumberFormat
import java.util.Locale

@Composable
fun RewardsLeaderboardScreen(
  profile: UserProfile,
  currentUserId: String,
  leaderboardState: UiState<List<LeaderboardEntry>>,
  strings: QuickStrings,
  onClaimMilestone: (QuestMilestone) -> Unit,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val isBangla = strings.isBangla

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    SingleChoiceSegmentedButtonRow(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 8.dp),
    ) {
      SegmentedButton(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
        modifier = Modifier.testTag("tab_leaderboard"),
      ) {
        Text(strings.leaderboard)
      }
      SegmentedButton(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
        modifier = Modifier.testTag("tab_quests"),
      ) {
        Text(strings.quests)
      }
    }

    if (selectedTab == 0) {
      when (leaderboardState) {
        is UiState.Loading -> {
          Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = EmeraldAccent)
          }
        }
        is UiState.Error -> {
          Surface(
            color = MaterialTheme.colorScheme.errorContainer,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = leaderboardState.message,
              color = MaterialTheme.colorScheme.onErrorContainer,
              modifier = Modifier.padding(16.dp),
            )
          }
        }
        is UiState.Success -> {
          val entries = leaderboardState.data
          if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(
                  imageVector = Icons.Rounded.EmojiEvents,
                  contentDescription = null,
                  tint = GoldCoin,
                  modifier = Modifier.size(48.dp),
                )
                Text(
                  text = if (isBangla) "এখনো কোনো স্কোর নেই — প্রথম হন!" else "No scores yet — play a round to lead!",
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          } else {
            LazyColumn(
              modifier = Modifier.fillMaxSize(),
              contentPadding = PaddingValues(bottom = 24.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              itemsIndexed(entries, key = { _, item -> item.userId }) { index, entry ->
                val isMe = entry.userId == currentUserId
                val rank = index + 1
                val rankColor = when (rank) {
                  1 -> GoldCoin
                  2 -> MaterialTheme.colorScheme.onSurface
                  3 -> GoldWarm
                  else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                Surface(
                  color = if (isMe) EmeraldAccent.copy(alpha = 0.12f) else ArcadeSurfaceElevated,
                  shape = RoundedCornerShape(16.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .border(
                      1.dp,
                      if (isMe) EmeraldAccent else ArcadeSurfaceBorder,
                      RoundedCornerShape(16.dp),
                    ),
                ) {
                  Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Row(
                      verticalAlignment = Alignment.CenterVertically,
                      horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                      Box(
                        modifier = Modifier
                          .size(36.dp)
                          .clip(CircleShape)
                          .background(rankColor.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center,
                      ) {
                        Text(
                          text = "#$rank",
                          style = MaterialTheme.typography.labelMedium,
                          color = rankColor,
                        )
                      }
                      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                          text = if (isMe) "${entry.displayName} (You)" else entry.displayName,
                          style = MaterialTheme.typography.titleMedium,
                          color = MaterialTheme.colorScheme.onSurface,
                        )
                        VipTierBadge(entry.tier)
                      }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                      Text(
                        text = "${NumberFormat.getNumberInstance(Locale.US).format(entry.totalScore)} XP",
                        style = MaterialTheme.typography.labelMedium,
                        color = EmeraldAccent,
                      )
                      Text(
                        text = "${NumberFormat.getNumberInstance(Locale.US).format(entry.coins)} Coins",
                        style = MaterialTheme.typography.bodyMedium,
                        color = GoldWarm,
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        items(QuickGameMilestones.all, key = { it.id }) { quest ->
          val claimed = profile.claimedMilestones.contains(quest.id)
          val eligible = quest.isEligible(profile)
          Surface(
            color = ArcadeSurfaceElevated,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
              .fillMaxWidth()
              .border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(18.dp)),
          ) {
            Row(
              modifier = Modifier.padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                Icon(
                  imageVector = if (claimed) Icons.Rounded.CheckCircle else Icons.Rounded.MilitaryTech,
                  contentDescription = null,
                  tint = if (claimed) EmeraldAccent else GoldCoin,
                  modifier = Modifier.size(30.dp),
                )
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text(
                    text = if (isBangla) quest.titleBn else quest.titleEn,
                    style = MaterialTheme.typography.titleMedium,
                  )
                  Text(
                    text = if (isBangla) quest.descBn else quest.descEn,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                  Text(
                    text = "+${quest.coinReward} Coins • +${quest.xpReward} XP",
                    style = MaterialTheme.typography.labelMedium,
                    color = GoldWarm,
                  )
                }
              }

              Button(
                onClick = { onClaimMilestone(quest) },
                enabled = !claimed && eligible,
                colors = ButtonDefaults.buttonColors(
                  containerColor = EmeraldAccent,
                  contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("claim_quest_${quest.id}"),
              ) {
                Text(
                  text = when {
                    claimed -> strings.claimed
                    eligible -> strings.claimReward
                    else -> strings.locked
                  },
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                )
              }
            }
          }
        }
      }
    }
  }
}
