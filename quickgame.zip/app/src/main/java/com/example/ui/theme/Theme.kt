package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val QuickGameDarkColorScheme = darkColorScheme(
  primary = EmeraldAccent,
  onPrimary = Color(0xFF032319),
  primaryContainer = Color(0xFF0A3D2E),
  onPrimaryContainer = EmeraldAccent,
  secondary = GoldCoin,
  onSecondary = Color(0xFF2B1D00),
  secondaryContainer = Color(0xFF3E2E08),
  onSecondaryContainer = GoldWarm,
  tertiary = IndigoPulse,
  onTertiary = Color.White,
  tertiaryContainer = Color(0xFF282257),
  onTertiaryContainer = Color(0xFFD6D0FF),
  background = ArcadeBg,
  onBackground = TextPrimary,
  surface = ArcadeSurface,
  onSurface = TextPrimary,
  surfaceVariant = ArcadeSurfaceElevated,
  onSurfaceVariant = TextSecondary,
  outline = ArcadeSurfaceBorder,
  outlineVariant = Color(0xFF263042),
  error = CoralAlert,
  onError = Color.White,
  errorContainer = Color(0xFF471822),
  onErrorContainer = Color(0xFFFFB3C0),
)

val QuickGameShapes = Shapes(
  small = RoundedCornerShape(10.dp),
  medium = RoundedCornerShape(16.dp),
  large = RoundedCornerShape(22.dp),
  extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun QuickGameTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = QuickGameDarkColorScheme,
    typography = QuickGameTypography,
    shapes = QuickGameShapes,
    content = content,
  )
}
