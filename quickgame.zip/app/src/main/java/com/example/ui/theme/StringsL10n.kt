package com.example.ui.theme

data class QuickStrings(
  val isBangla: Boolean,
) {
  val navArena get() = if (isBangla) "অ্যারেনা" else "Arena"
  val navGames get() = if (isBangla) "গেমস" else "Games"
  val navRewards get() = if (isBangla) "রিওয়ার্ডস" else "Rewards"
  val navMember get() = if (isBangla) "মেম্বার" else "Member"

  val livePoolLabel get() = if (isBangla) "লাইভ কমিউনিটি পুল" else "LIVE COMMUNITY POOL"
  val virtualCoinsOnly get() = if (isBangla) "ভার্চুয়াল কুইককয়েন • ফান মোড" else "Virtual QuickCoins • Free Play"
  val featuredTitle get() = if (isBangla) "দ্রুত খেলুন, কয়েন জিতুন" else "Play Fast. Win QuickCoins."
  val featuredSub get() = if (isBangla) "রিয়েল-টাইম Firebase স্কোর ও ডেইলি স্ট্রিক" else "Real-time cloud progress & daily streak bonuses"
  val playNow get() = if (isBangla) "এখনই খেলুন" else "Play Now"

  val quickPromos get() = if (isBangla) "কুইক প্রোমো ও বোনাস" else "Quick Promos & Bonuses"
  val dailyCheckIn get() = if (isBangla) "ডেইলি বোনাস" else "Daily Bonus"
  val claimedToday get() = if (isBangla) "আজ নেওয়া হয়েছে" else "Claimed Today"
  val claimNow get() = if (isBangla) "ক্লেইম করুন" else "Claim Bonus"
  val luckySpin get() = if (isBangla) "লাকি স্পিন" else "Lucky Spin"
  val spinNow get() = if (isBangla) "স্পিন (২৫ কয়েন)" else "Spin (25 Coins)"

  val miniGames get() = if (isBangla) "মিনি-গেমস" else "Mini-Games"
  val allGames get() = if (isBangla) "সব গেম" else "All Games"
  val searchHint get() = if (isBangla) "গেম খুঁজুন..." else "Search mini-games..."

  val leaderboard get() = if (isBangla) "লিডারবোর্ড" else "Leaderboard"
  val quests get() = if (isBangla) "কোয়েস্ট" else "Quests"
  val claimReward get() = if (isBangla) "সংগ্রহ করুন" else "Claim"
  val claimed get() = if (isBangla) "সংগৃহীত" else "Claimed"
  val locked get() = if (isBangla) "লকড" else "In Progress"

  val memberCenter get() = if (isBangla) "মেম্বার সেন্টার" else "Member Center"
  val walletBalance get() = if (isBangla) "কুইককয়েন ব্যালেন্স" else "QuickCoin Balance"
  val totalXp get() = if (isBangla) "মোট XP" else "Total XP"
  val gamesPlayed get() = if (isBangla) "খেলা হয়েছে" else "Games Played"
  val bestScore get() = if (isBangla) "সেরা স্কোর" else "Best Score"
  val recentActivity get() = if (isBangla) "সাম্প্রতিক গেম হিস্ট্রি" else "Recent Activity"
  val editName get() = if (isBangla) "নাম পরিবর্তন" else "Edit Name"
  val signOut get() = if (isBangla) "সাইন আউট" else "Sign Out"
  val noSessionsYet get() = if (isBangla) "এখনও কোনো গেম খেলা হয়নি। অ্যারেনা থেকে খেলা শুরু করুন!" else "No rounds played yet. Jump into a mini-game!"
}
