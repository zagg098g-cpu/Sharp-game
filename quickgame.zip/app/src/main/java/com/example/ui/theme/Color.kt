package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ArcadeBg = Color(0xFF10151F)
val ArcadeSurface = Color(0xFF181F2B)
val ArcadeSurfaceElevated = Color(0xFF222B3B)
val ArcadeSurfaceBorder = Color(0xFF2F3B50)

val EmeraldAccent = Color(0xFF00E5A3)
val EmeraldDim = Color(0xFF00B37E)
val GoldCoin = Color(0xFFFFB800)
val GoldWarm = Color(0xFFFFD166)
val IndigoPulse = Color(0xFF6C5CE7)
val CyanGlow = Color(0xFF38BDF8)
val CoralAlert = Color(0xFFFF5C77)

val TextPrimary = Color(0xFFF4F7FB)
val TextSecondary = Color(0xFF9AA8BE)
val TextMuted = Color(0xFF6B7A94)
