package com.example.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.MiniGameId
import com.example.ui.components.MiniGameCard
import com.example.ui.theme.ArcadeSurfaceBorder
import com.example.ui.theme.ArcadeSurfaceElevated
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.QuickStrings

@Composable
fun GamesHubScreen(
  strings: QuickStrings,
  onPlayGame: (MiniGameId) -> Unit,
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("All") }
  val categories = remember { listOf("All", "Reflex", "Memory", "Puzzle", "Arcade") }

  val filteredGames = remember(searchQuery, selectedCategory) {
    MiniGameId.entries.filter { game ->
      val matchesCat = selectedCategory == "All" || game.category == selectedCategory
      val q = searchQuery.trim()
      val matchesQuery = q.isEmpty() ||
        game.titleEn.contains(q, ignoreCase = true) ||
        game.titleBn.contains(q, ignoreCase = true) ||
        game.category.contains(q, ignoreCase = true)
      matchesCat && matchesQuery
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      placeholder = { Text(strings.searchHint) },
      leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
      singleLine = true,
      shape = RoundedCornerShape(16.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = ArcadeSurfaceElevated,
        unfocusedContainerColor = ArcadeSurfaceElevated,
        focusedBorderColor = EmeraldAccent,
        unfocusedBorderColor = ArcadeSurfaceBorder,
      ),
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 8.dp)
        .testTag("games_search_input"),
    )

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      categories.forEach { category ->
        FilterChip(
          selected = selectedCategory == category,
          onClick = { selectedCategory = category },
          label = { Text(category) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = EmeraldAccent.copy(alpha = 0.2f),
            selectedLabelColor = EmeraldAccent,
          ),
        )
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(bottom = 24.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      items(filteredGames, key = { it.id }) { game ->
        MiniGameCard(
          game = game,
          isBangla = strings.isBangla,
          playLabel = strings.playNow,
          onPlay = { onPlayGame(game) },
        )
      }
    }
  }
}
