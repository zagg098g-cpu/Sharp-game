package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.GameSession
import com.example.model.MiniGameId
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.VipTierBadge
import com.example.ui.components.miniGameAccent
import com.example.ui.components.miniGameIcon
import com.example.ui.theme.ArcadeSurfaceBorder
import com.example.ui.theme.ArcadeSurfaceElevated
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.GoldCoin
import com.example.ui.theme.GoldWarm
import com.example.ui.theme.QuickStrings
import com.google.firebase.Timestamp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun MemberCenterScreen(
  profile: UserProfile,
  sessionsState: UiState<List<GameSession>>,
  strings: QuickStrings,
  onUpdateDisplayName: (String) -> Unit,
  onToggleLanguage: () -> Unit,
  onSignOut: () -> Unit,
) {
  var showEditDialog by remember { mutableStateOf(false) }
  var nameInput by remember(profile.displayName) { mutableStateOf(profile.displayName) }
  val isBangla = strings.isBangla

  if (showEditDialog) {
    AlertDialog(
      onDismissRequest = { showEditDialog = false },
      containerColor = ArcadeSurfaceElevated,
      title = { Text(strings.editName) },
      text = {
        OutlinedTextField(
          value = nameInput,
          onValueChange = { if (it.length <= 60) nameInput = it },
          singleLine = true,
          label = { Text(if (isBangla) "প্লেয়ার নাম" else "Player Nickname") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("edit_name_input"),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            onUpdateDisplayName(nameInput)
            showEditDialog = false
          },
          colors = ButtonDefaults.buttonColors(
            containerColor = EmeraldAccent,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
          modifier = Modifier.testTag("confirm_edit_name_button"),
        ) {
          Text(if (isBangla) "সেভ করুন" else "Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { showEditDialog = false }) {
          Text(if (isBangla) "বাতিল" else "Cancel")
        }
      },
    )
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Member Profile Card
    item {
      Surface(
        color = ArcadeSurfaceElevated,
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(22.dp)),
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.weight(1f),
          ) {
            Image(
              painter = painterResource(id = R.drawable.img_member_crest),
              contentDescription = "Member VIP Crest",
              contentScale = ContentScale.Crop,
              modifier = Modifier
                .size(60.dp)
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, GoldCoin.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Text(
                  text = profile.displayName,
                  style = MaterialTheme.typography.titleLarge,
                )
                VipTierBadge(profile.vipTier)
              }
              Text(
                text = "ID: ${profile.userId.take(10)}...",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }

          IconButton(
            onClick = {
              nameInput = profile.displayName
              showEditDialog = true
            },
            modifier = Modifier.testTag("edit_name_button"),
          ) {
            Icon(
              imageVector = Icons.Rounded.Edit,
              contentDescription = strings.editName,
              tint = EmeraldAccent,
            )
          }
        }
      }
    }

    // 2. Stats Grid
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          StatBox(
            label = strings.walletBalance,
            value = NumberFormat.getNumberInstance(Locale.US).format(profile.coins),
            accent = GoldWarm,
            modifier = Modifier.weight(1f),
          )
          StatBox(
            label = strings.totalXp,
            value = NumberFormat.getNumberInstance(Locale.US).format(profile.xp),
            accent = EmeraldAccent,
            modifier = Modifier.weight(1f),
          )
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          StatBox(
            label = strings.gamesPlayed,
            value = profile.gamesPlayed.toString(),
            accent = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
          )
          StatBox(
            label = strings.bestScore,
            value = profile.bestScore.toString(),
            accent = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.weight(1f),
          )
        }
      }
    }

    // 3. Language & Account Actions
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedButton(
          onClick = onToggleLanguage,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("member_lang_button"),
        ) {
          Icon(Icons.Rounded.Translate, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(6.dp))
          Text(if (isBangla) "Switch to English" else "বাংলায় দেখুন")
        }

        Button(
          onClick = onSignOut,
          colors = ButtonDefaults.buttonColors(
            containerColor = CoralAlert.copy(alpha = 0.16f),
            contentColor = CoralAlert,
          ),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier
            .weight(1f)
            .testTag("sign_out_button"),
        ) {
          Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(6.dp))
          Text(strings.signOut, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 4. Recent Activity Header
    item {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(Icons.Rounded.History, contentDescription = null, tint = EmeraldAccent)
        Text(
          text = strings.recentActivity,
          style = MaterialTheme.typography.titleLarge,
        )
      }
    }

    // 5. Recent Sessions List
    when (sessionsState) {
      is UiState.Loading -> {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp),
            contentAlignment = Alignment.Center,
          ) {
            CircularProgressIndicator(color = EmeraldAccent)
          }
        }
      }
      is UiState.Error -> {
        item {
          Text(
            text = sessionsState.message,
            color = CoralAlert,
            style = MaterialTheme.typography.bodyMedium,
          )
        }
      }
      is UiState.Success -> {
        val sessions = sessionsState.data
        if (sessions.isEmpty()) {
          item {
            Surface(
              color = ArcadeSurfaceElevated,
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(16.dp)),
            ) {
              Text(
                text = strings.noSessionsYet,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(16.dp),
              )
            }
          }
        } else {
          items(sessions, key = { it.id }) { session ->
            val game = MiniGameId.fromId(session.gameId)
            val accent = miniGameAccent(game)
            val displayTime = remember(session.createdAt) {
              val ts = session.createdAt ?: Timestamp.now()
              SimpleDateFormat("MMM d, HH:mm", Locale.US).format(ts.toDate())
            }
            Surface(
              color = ArcadeSurfaceElevated,
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(14.dp)),
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                  Box(
                    modifier = Modifier
                      .size(38.dp)
                      .clip(CircleShape)
                      .background(accent.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center,
                  ) {
                    Icon(
                      imageVector = miniGameIcon(game),
                      contentDescription = session.gameTitle,
                      tint = accent,
                      modifier = Modifier.size(20.dp),
                    )
                  }
                  Column {
                    Text(
                      text = if (isBangla) game.titleBn else game.titleEn,
                      style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                      text = "$displayTime • Score ${session.score}",
                      style = MaterialTheme.typography.bodyMedium,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
                Column(horizontalAlignment = Alignment.End) {
                  Text(
                    text = "+${session.coinsEarned} Coins",
                    style = MaterialTheme.typography.labelMedium,
                    color = GoldWarm,
                  )
                  Text(
                    text = "+${session.xpEarned} XP",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldAccent,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun StatBox(
  label: String,
  value: String,
  accent: androidx.compose.ui.graphics.Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = ArcadeSurfaceElevated,
    shape = RoundedCornerShape(16.dp),
    modifier = modifier.border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(16.dp)),
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
      Text(
        text = value,
        style = MaterialTheme.typography.headlineSmall,
        color = accent,
      )
    }
  }
}
