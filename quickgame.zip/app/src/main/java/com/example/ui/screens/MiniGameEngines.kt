package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ArcadeSurfaceBorder
import com.example.ui.theme.ArcadeSurfaceElevated
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.GoldCoin
import com.example.ui.theme.IndigoPulse
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import kotlin.random.Random

@Composable
fun ReflexTapGame(
  isActive: Boolean,
  onScoreChange: (Int) -> Unit,
) {
  var targetNormX by remember { mutableFloatStateOf(0.5f) }
  var targetNormY by remember { mutableFloatStateOf(0.5f) }
  var isBonusOrb by remember { mutableStateOf(false) }
  var combo by remember { mutableIntStateOf(0) }
  var score by remember { mutableIntStateOf(0) }

  LaunchedEffect(isActive) {
    if (!isActive) return@LaunchedEffect
    while (true) {
      delay(1250L)
      targetNormX = Random.nextFloat().coerceIn(0.12f, 0.88f)
      targetNormY = Random.nextFloat().coerceIn(0.12f, 0.88f)
      isBonusOrb = Random.nextFloat() < 0.25f
    }
  }

  Column(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Text(
        text = "Combo: x${(1 + combo / 3).coerceAtMost(5)}",
        style = MaterialTheme.typography.titleMedium,
        color = GoldCoin,
      )
      Text(
        text = "Tap the glowing orbs!",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }

    BoxWithConstraints(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .clip(RoundedCornerShape(22.dp))
        .background(ArcadeSurfaceElevated)
        .border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(22.dp)),
    ) {
      val orbSize = 68.dp
      val maxX = (constraints.maxWidth - 200).coerceAtLeast(1)
      val maxY = (constraints.maxHeight - 200).coerceAtLeast(1)

      Box(
        modifier = Modifier
          .offset {
            IntOffset(
              x = (targetNormX * maxX).roundToInt(),
              y = (targetNormY * maxY).roundToInt(),
            )
          }
          .size(orbSize)
          .clip(CircleShape)
          .background(if (isBonusOrb) GoldCoin else EmeraldAccent)
          .clickable(enabled = isActive) {
            combo += 1
            val mult = (1 + combo / 3).coerceAtMost(5)
            score += (if (isBonusOrb) 25 else 10) * mult
            onScoreChange(score)
            targetNormX = Random.nextFloat().coerceIn(0.1f, 0.9f)
            targetNormY = Random.nextFloat().coerceIn(0.1f, 0.9f)
            isBonusOrb = Random.nextFloat() < 0.25f
          }
          .testTag("reflex_target_orb"),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Rounded.Bolt,
          contentDescription = "Target Orb",
          tint = Color.Black,
          modifier = Modifier.size(30.dp),
        )
      }
    }
  }
}

@Composable
fun MemoryFlashGame(
  isActive: Boolean,
  onScoreChange: (Int) -> Unit,
) {
  val sequence = remember { mutableStateListOf<Int>() }
  var playerIndex by remember { mutableIntStateOf(0) }
  var litTile by remember { mutableIntStateOf(-1) }
  var isShowingPattern by remember { mutableStateOf(true) }
  var score by remember { mutableIntStateOf(0) }
  var round by remember { mutableIntStateOf(1) }

  suspend fun playPattern() {
    isShowingPattern = true
    delay(400L)
    for (tile in sequence) {
      litTile = tile
      delay(420L)
      litTile = -1
      delay(180L)
    }
    isShowingPattern = false
    playerIndex = 0
  }

  LaunchedEffect(isActive, round) {
    if (!isActive) return@LaunchedEffect
    if (round == 1 && sequence.isEmpty()) {
      sequence.add(Random.nextInt(9))
      sequence.add(Random.nextInt(9))
    }
    playPattern()
  }

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    Text(
      text = if (isShowingPattern) "Watch pattern (Round $round)..." else "Your turn! Repeat ${sequence.size} tiles",
      style = MaterialTheme.typography.titleMedium,
      color = if (isShowingPattern) GoldCoin else EmeraldAccent,
    )

    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      for (r in 0..2) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          for (c in 0..2) {
            val idx = r * 3 + c
            val isLit = litTile == idx
            val bgColor by animateColorAsState(
              targetValue = if (isLit) EmeraldAccent else ArcadeSurfaceElevated,
              label = "tileColor",
            )
            Box(
              modifier = Modifier
                .weight(1f)
                .aspectRatio(1f)
                .clip(RoundedCornerShape(18.dp))
                .background(bgColor)
                .border(1.5.dp, if (isLit) Color.White else ArcadeSurfaceBorder, RoundedCornerShape(18.dp))
                .clickable(enabled = isActive && !isShowingPattern) {
                  if (sequence[playerIndex] == idx) {
                    score += 20
                    onScoreChange(score)
                    playerIndex += 1
                    if (playerIndex >= sequence.size) {
                      score += 40
                      onScoreChange(score)
                      sequence.add(Random.nextInt(9))
                      round += 1
                    }
                  } else {
                    // Restart sequence gently on mistake
                    sequence.clear()
                    sequence.add(Random.nextInt(9))
                    sequence.add(Random.nextInt(9))
                    round += 1
                  }
                }
                .testTag("memory_tile_$idx"),
            )
          }
        }
      }
    }
  }
}

@Composable
fun ColorBlitzGame(
  isActive: Boolean,
  onScoreChange: (Int) -> Unit,
) {
  val palette = remember {
    listOf(
      "EMERALD" to EmeraldAccent,
      "GOLD" to GoldCoin,
      "CORAL" to CoralAlert,
      "INDIGO" to CyanGlow,
    )
  }
  var wordIdx by remember { mutableIntStateOf(Random.nextInt(palette.size)) }
  var inkIdx by remember { mutableIntStateOf(Random.nextInt(palette.size)) }
  var streak by remember { mutableIntStateOf(0) }
  var score by remember { mutableIntStateOf(0) }

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    Text(
      text = "Tap the INK COLOR (Streak: $streak)",
      style = MaterialTheme.typography.titleMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Surface(
      color = ArcadeSurfaceElevated,
      shape = RoundedCornerShape(24.dp),
      modifier = Modifier
        .fillMaxWidth()
        .height(160.dp)
        .border(1.5.dp, ArcadeSurfaceBorder, RoundedCornerShape(24.dp)),
    ) {
      Box(contentAlignment = Alignment.Center) {
        Text(
          text = palette[wordIdx].first,
          style = MaterialTheme.typography.displaySmall,
          color = palette[inkIdx].second,
          fontWeight = FontWeight.Bold,
        )
      }
    }

    Column(
      modifier = Modifier.fillMaxWidth(),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      palette.chunked(2).forEachIndexed { rowIdx, pair ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          pair.forEachIndexed { colIdx, (label, color) ->
            val actualIdx = rowIdx * 2 + colIdx
            Button(
              onClick = {
                if (!isActive) return@Button
                if (actualIdx == inkIdx) {
                  streak += 1
                  score += 25 + (streak * 5).coerceAtMost(40)
                } else {
                  streak = 0
                }
                onScoreChange(score)
                wordIdx = Random.nextInt(palette.size)
                inkIdx = Random.nextInt(palette.size)
              },
              colors = ButtonDefaults.buttonColors(
                containerColor = color,
                contentColor = Color.Black,
              ),
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier
                .weight(1f)
                .height(60.dp)
                .testTag("color_choice_$actualIdx"),
            ) {
              Text(label, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

private data class FallingItem(
  val xNorm: Float,
  var yNorm: Float,
  val isHazard: Boolean,
  val speed: Float,
)

@Composable
fun CoinDashCanvasGame(
  isActive: Boolean,
  onScoreChange: (Int) -> Unit,
) {
  var paddleX by remember { mutableFloatStateOf(0.5f) }
  val items = remember { mutableStateListOf<FallingItem>() }
  var score by remember { mutableIntStateOf(0) }
  var tick by remember { mutableIntStateOf(0) }

  LaunchedEffect(isActive) {
    if (!isActive) return@LaunchedEffect
    var spawnCounter = 0
    while (true) {
      delay(30L)
      tick += 1
      spawnCounter += 1
      if (spawnCounter >= 18) {
        spawnCounter = 0
        items.add(
          FallingItem(
            xNorm = Random.nextFloat().coerceIn(0.08f, 0.92f),
            yNorm = 0f,
            isHazard = Random.nextFloat() < 0.28f,
            speed = Random.nextFloat() * 0.010f + 0.014f,
          )
        )
      }

      val iterator = items.listIterator()
      while (iterator.hasNext()) {
        val item = iterator.next()
        item.yNorm += item.speed
        val caught = item.yNorm in 0.82f..0.93f && kotlin.math.abs(item.xNorm - paddleX) < 0.14f
        if (caught) {
          score = if (item.isHazard) (score - 30).coerceAtLeast(0) else score + 30
          onScoreChange(score)
          iterator.remove()
        } else if (item.yNorm > 1.02f) {
          iterator.remove()
        }
      }
    }
  }

  Column(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Text(
      text = "Drag or tap left/right to catch Gold Coins! Avoid Red Bombs.",
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Canvas(
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .clip(RoundedCornerShape(22.dp))
        .background(ArcadeSurfaceElevated)
        .border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(22.dp))
        .pointerInput(isActive) {
          detectDragGestures { change, _ ->
            change.consume()
            if (isActive && size.width > 0) {
              paddleX = (change.position.x / size.width).coerceIn(0.12f, 0.88f)
            }
          }
        }
        .pointerInput(isActive) {
          detectTapGestures { offset ->
            if (isActive && size.width > 0) {
              paddleX = (offset.x / size.width).coerceIn(0.12f, 0.88f)
            }
          }
        }
        .testTag("coin_dash_canvas"),
    ) {
      // Force redraw on tick
      @Suppress("UNUSED_EXPRESSION")
      tick

      // Draw falling coins & hazards
      items.forEach { item ->
        val cx = item.xNorm * size.width
        val cy = item.yNorm * size.height
        if (item.isHazard) {
          drawCircle(color = CoralAlert, radius = 15.dp.toPx(), center = Offset(cx, cy))
          drawCircle(color = Color.Black, radius = 5.dp.toPx(), center = Offset(cx, cy))
        } else {
          drawCircle(color = GoldCoin, radius = 15.dp.toPx(), center = Offset(cx, cy))
          drawCircle(color = Color.White.copy(alpha = 0.45f), radius = 6.dp.toPx(), center = Offset(cx - 3.dp.toPx(), cy - 3.dp.toPx()))
        }
      }

      // Draw player shield paddle
      val paddleW = size.width * 0.24f
      val paddleH = 18.dp.toPx()
      val px = (paddleX * size.width - paddleW / 2f).coerceIn(8.dp.toPx(), size.width - paddleW - 8.dp.toPx())
      val py = size.height * 0.86f
      drawRoundRect(
        color = EmeraldAccent,
        topLeft = Offset(px, py),
        size = Size(paddleW, paddleH),
        cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx()),
      )
    }
  }
}
