package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.MiniGameId
import com.example.model.UserProfile
import com.example.ui.components.JackpotPoolTicker
import com.example.ui.components.LuckySpinDialog
import com.example.ui.components.MiniGameCard
import com.example.ui.theme.ArcadeBg
import com.example.ui.theme.ArcadeSurfaceBorder
import com.example.ui.theme.ArcadeSurfaceElevated
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.GoldCoin
import com.example.ui.theme.IndigoPulse
import com.example.ui.theme.QuickStrings

@Composable
fun ArenaScreen(
  profile: UserProfile,
  todayKey: String,
  strings: QuickStrings,
  onPlayGame: (MiniGameId) -> Unit,
  onClaimDaily: () -> Unit,
  onSpinWon: (Long) -> Unit,
  onViewAllGames: () -> Unit,
) {
  var showSpinDialog by remember { mutableStateOf(false) }
  val isDailyClaimed = profile.lastDailyClaimDate == todayKey
  val isBangla = strings.isBangla

  if (showSpinDialog) {
    LuckySpinDialog(
      currentCoins = profile.coins,
      isBangla = isBangla,
      onDismiss = { showSpinDialog = false },
      onSpinWon = onSpinWon,
    )
  }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Live Community Virtual Pool Ticker
    item {
      JackpotPoolTicker(baseCoins = profile.coins, strings = strings)
    }

    // 2. Hero Featured Banner
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(188.dp)
          .clip(RoundedCornerShape(24.dp))
          .border(1.dp, EmeraldAccent.copy(alpha = 0.35f), RoundedCornerShape(24.dp)),
      ) {
        Image(
          painter = painterResource(id = R.drawable.img_hero_arena),
          contentDescription = "QuickGame Arena Banner",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.horizontalGradient(
                listOf(
                  ArcadeBg.copy(alpha = 0.92f),
                  ArcadeBg.copy(alpha = 0.55f),
                  Color.Transparent,
                )
              )
            )
        )
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
          verticalArrangement = Arrangement.SpaceBetween,
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(
              color = EmeraldAccent.copy(alpha = 0.2f),
              shape = RoundedCornerShape(50),
            ) {
              Text(
                text = if (isBangla) "ফিচার্ড অ্যারেনা" else "FEATURED ARENA",
                style = MaterialTheme.typography.labelSmall,
                color = EmeraldAccent,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
              )
            }
            Text(
              text = strings.featuredTitle,
              style = MaterialTheme.typography.headlineSmall,
              color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
              text = strings.featuredSub,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          Button(
            onClick = { onPlayGame(MiniGameId.COIN_DASH) },
            colors = ButtonDefaults.buttonColors(
              containerColor = EmeraldAccent,
              contentColor = MaterialTheme.colorScheme.onPrimary,
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.testTag("hero_play_button"),
          ) {
            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(strings.playNow, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // 3. Quick Promos (Daily Check-In & Lucky Spin)
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = strings.quickPromos,
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          // Daily Bonus Card
          Surface(
            color = ArcadeSurfaceElevated,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
              .weight(1f)
              .border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(18.dp)),
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(
                  imageVector = if (isDailyClaimed) Icons.Rounded.CheckCircle else Icons.Rounded.CardGiftcard,
                  contentDescription = strings.dailyCheckIn,
                  tint = if (isDailyClaimed) EmeraldAccent else GoldCoin,
                  modifier = Modifier.size(22.dp),
                )
                Text(
                  text = strings.dailyCheckIn,
                  style = MaterialTheme.typography.titleMedium,
                )
              }
              Text(
                text = "+${(100L + profile.streakDays * 25L).coerceAtMost(500L)} Coins",
                style = MaterialTheme.typography.labelMedium,
                color = GoldCoin,
              )
              Button(
                onClick = onClaimDaily,
                enabled = !isDailyClaimed,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = EmeraldAccent,
                  contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("claim_daily_button"),
              ) {
                Text(
                  text = if (isDailyClaimed) strings.claimedToday else strings.claimNow,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                )
              }
            }
          }

          // Lucky Spin Card
          Surface(
            color = ArcadeSurfaceElevated,
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
              .weight(1f)
              .border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(18.dp)),
          ) {
            Column(
              modifier = Modifier.padding(14.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Casino,
                  contentDescription = strings.luckySpin,
                  tint = IndigoPulse,
                  modifier = Modifier.size(22.dp),
                )
                Text(
                  text = strings.luckySpin,
                  style = MaterialTheme.typography.titleMedium,
                )
              }
              Text(
                text = "Up to +200 Coins",
                style = MaterialTheme.typography.labelMedium,
                color = EmeraldAccent,
              )
              Button(
                onClick = { showSpinDialog = true },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = IndigoPulse,
                  contentColor = Color.White,
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("open_lucky_spin_button"),
              ) {
                Text(
                  text = strings.spinNow,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                )
              }
            }
          }
        }
      }
    }

    // 4. Mini-Games Grid Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = strings.miniGames,
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Surface(
          onClick = onViewAllGames,
          color = Color.Transparent,
          modifier = Modifier.testTag("see_all_games_button"),
        ) {
          Text(
            text = strings.allGames,
            style = MaterialTheme.typography.labelLarge,
            color = EmeraldAccent,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
          )
        }
      }
    }

    // 5. Mini-Game Cards (2-column pairs)
    val games = MiniGameId.entries
    items(games.chunked(2).size) { rowIdx ->
      val pair = games.chunked(2)[rowIdx]
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        pair.forEach { game ->
          MiniGameCard(
            game = game,
            isBangla = isBangla,
            playLabel = strings.playNow,
            onPlay = { onPlayGame(game) },
            modifier = Modifier.weight(1f),
          )
        }
        if (pair.size == 1) {
          Spacer(Modifier.weight(1f))
        }
      }
    }
  }
}
