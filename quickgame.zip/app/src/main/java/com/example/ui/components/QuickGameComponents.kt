package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MonetizationOn
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.MiniGameId
import com.example.ui.theme.ArcadeSurfaceBorder
import com.example.ui.theme.ArcadeSurfaceElevated
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.GoldCoin
import com.example.ui.theme.GoldWarm
import com.example.ui.theme.IndigoPulse
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.QuickStrings
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale
import kotlin.random.Random

@Composable
fun QuickGameTopBar(
  coins: Long,
  streakDays: Long,
  isBangla: Boolean,
  onToggleLanguage: () -> Unit,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Box(
        modifier = Modifier
          .size(38.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(
            Brush.linearGradient(listOf(EmeraldAccent, IndigoPulse))
          ),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Rounded.Bolt,
          contentDescription = "QuickGame Logo",
          tint = MaterialTheme.colorScheme.onPrimary,
          modifier = Modifier.size(22.dp),
        )
      }
      Column {
        Text(
          text = "QuickGame",
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
          text = if (isBangla) "কুইকগেম • লাইভ" else "ARCADE HUB",
          style = MaterialTheme.typography.labelSmall,
          color = EmeraldAccent,
        )
      }
    }

    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Surface(
        color = ArcadeSurfaceElevated,
        shape = RoundedCornerShape(50),
        modifier = Modifier.border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(50)),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Icon(
            imageVector = Icons.Rounded.LocalFireDepartment,
            contentDescription = "Streak",
            tint = CoralAlert,
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = "${streakDays}d",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
        }
      }

      Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(50),
        modifier = Modifier.border(1.dp, GoldCoin.copy(alpha = 0.5f), RoundedCornerShape(50)),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
          Icon(
            imageVector = Icons.Rounded.MonetizationOn,
            contentDescription = "QuickCoins",
            tint = GoldCoin,
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = NumberFormat.getNumberInstance(Locale.US).format(coins),
            style = MaterialTheme.typography.labelMedium,
            color = GoldWarm,
          )
        }
      }

      Surface(
        onClick = onToggleLanguage,
        color = ArcadeSurfaceElevated,
        shape = RoundedCornerShape(50),
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(50))
          .testTag("language_toggle_button"),
      ) {
        Text(
          text = if (isBangla) "বাং" else "EN",
          style = MaterialTheme.typography.labelMedium,
          color = EmeraldAccent,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
        )
      }
    }
  }
}

@Composable
fun JackpotPoolTicker(
  baseCoins: Long,
  strings: QuickStrings,
  modifier: Modifier = Modifier,
) {
  var displayPool by remember(baseCoins) { mutableLongStateOf(128_450L + baseCoins) }
  LaunchedEffect(baseCoins) {
    while (true) {
      delay(1600L)
      displayPool += Random.nextLong(12L, 48L)
    }
  }

  val infiniteTransition = rememberInfiniteTransition(label = "poolGlow")
  val glowAlpha by infiniteTransition.animateFloat(
    initialValue = 0.45f,
    targetValue = 0.9f,
    animationSpec = infiniteRepeatable(
      animation = tween(1400),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "glowAlpha",
  )

  Surface(
    shape = RoundedCornerShape(18.dp),
    color = ArcadeSurfaceElevated,
    modifier = modifier
      .fillMaxWidth()
      .border(
        width = 1.2.dp,
        brush = Brush.horizontalGradient(
          listOf(
            GoldCoin.copy(alpha = glowAlpha),
            EmeraldAccent.copy(alpha = glowAlpha),
          )
        ),
        shape = RoundedCornerShape(18.dp),
      ),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(EmeraldAccent)
          )
          Text(
            text = strings.livePoolLabel,
            style = MaterialTheme.typography.labelSmall,
            color = EmeraldAccent,
          )
        }
        Text(
          text = strings.virtualCoinsOnly,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Icon(
          imageVector = Icons.Rounded.AutoAwesome,
          contentDescription = null,
          tint = GoldCoin,
          modifier = Modifier.size(20.dp),
        )
        Text(
          text = NumberFormat.getNumberInstance(Locale.US).format(displayPool),
          fontFamily = JetBrainsMonoFontFamily,
          fontWeight = FontWeight.Bold,
          style = MaterialTheme.typography.headlineSmall,
          color = GoldWarm,
        )
      }
    }
  }
}

@Composable
fun VipTierBadge(tier: String) {
  val (bg, fg) = when (tier) {
    "Diamond" -> CyanGlow.copy(alpha = 0.16f) to CyanGlow
    "Gold" -> GoldCoin.copy(alpha = 0.18f) to GoldWarm
    "Silver" -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.16f) to MaterialTheme.colorScheme.onSurface
    else -> IndigoPulse.copy(alpha = 0.2f) to MaterialTheme.colorScheme.onTertiaryContainer
  }
  Surface(
    color = bg,
    shape = RoundedCornerShape(50),
    modifier = Modifier.border(1.dp, fg.copy(alpha = 0.5f), RoundedCornerShape(50)),
  ) {
    Text(
      text = "$tier VIP",
      style = MaterialTheme.typography.labelSmall,
      fontWeight = FontWeight.Bold,
      color = fg,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
    )
  }
}

fun miniGameIcon(game: MiniGameId): ImageVector = when (game) {
  MiniGameId.REFLEX_TAP -> Icons.Rounded.TouchApp
  MiniGameId.MEMORY_FLASH -> Icons.Rounded.GridView
  MiniGameId.COLOR_BLITZ -> Icons.Rounded.Palette
  MiniGameId.COIN_DASH -> Icons.Rounded.SportsEsports
}

fun miniGameAccent(game: MiniGameId): Color = when (game) {
  MiniGameId.REFLEX_TAP -> EmeraldAccent
  MiniGameId.MEMORY_FLASH -> IndigoPulse
  MiniGameId.COLOR_BLITZ -> CoralAlert
  MiniGameId.COIN_DASH -> GoldCoin
}

@Composable
fun MiniGameCard(
  game: MiniGameId,
  isBangla: Boolean,
  playLabel: String,
  onPlay: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val accent = miniGameAccent(game)
  Surface(
    shape = RoundedCornerShape(20.dp),
    color = ArcadeSurfaceElevated,
    modifier = modifier
      .fillMaxWidth()
      .border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(20.dp))
      .clip(RoundedCornerShape(20.dp))
      .clickable(onClick = onPlay)
      .testTag("game_card_${game.id}"),
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
          modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(accent.copy(alpha = 0.16f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = miniGameIcon(game),
            contentDescription = game.titleEn,
            tint = accent,
            modifier = Modifier.size(24.dp),
          )
        }
        Surface(
          color = accent.copy(alpha = 0.14f),
          shape = RoundedCornerShape(50),
        ) {
          Text(
            text = game.category,
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
          text = if (isBangla) game.titleBn else game.titleEn,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = if (isBangla) game.subtitleBn else game.subtitleEn,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = game.rewardHint,
          style = MaterialTheme.typography.labelMedium,
          color = GoldWarm,
        )
        Surface(
          color = accent,
          shape = RoundedCornerShape(12.dp),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
          ) {
            Icon(
              imageVector = Icons.Rounded.PlayArrow,
              contentDescription = playLabel,
              tint = MaterialTheme.colorScheme.onPrimary,
              modifier = Modifier.size(16.dp),
            )
            Text(
              text = playLabel,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onPrimary,
            )
          }
        }
      }
    }
  }
}

@Composable
fun LuckySpinDialog(
  currentCoins: Long,
  isBangla: Boolean,
  onDismiss: () -> Unit,
  onSpinWon: (Long) -> Unit,
) {
  val prizes = remember { listOf(10L, 40L, 25L, 100L, 15L, 60L, 200L, 30L) }
  val colors = remember {
    listOf(
      IndigoPulse, EmeraldAccent, CyanGlow, GoldCoin,
      CoralAlert, EmeraldAccent, GoldWarm, IndigoPulse
    )
  }
  val rotation = remember { Animatable(0f) }
  val scope = rememberCoroutineScope()
  var isSpinning by remember { mutableStateOf(false) }
  var resultCoins by remember { mutableStateOf<Long?>(null) }

  AlertDialog(
    onDismissRequest = { if (!isSpinning) onDismiss() },
    containerColor = ArcadeSurfaceElevated,
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(Icons.Rounded.Casino, contentDescription = null, tint = GoldCoin)
        Text(
          text = if (isBangla) "লাকি কয়েন স্পিন" else "Lucky Coin Wheel",
          style = MaterialTheme.typography.titleLarge,
        )
      }
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        Box(
          modifier = Modifier.size(210.dp),
          contentAlignment = Alignment.Center,
        ) {
          Canvas(modifier = Modifier.size(196.dp)) {
            val sweep = 360f / prizes.size
            rotate(rotation.value) {
              prizes.indices.forEach { idx ->
                drawArc(
                  color = colors[idx].copy(alpha = 0.85f),
                  startAngle = idx * sweep - 90f,
                  sweepAngle = sweep,
                  useCenter = true,
                  size = Size(size.width, size.height),
                )
              }
            }
            drawCircle(
              color = ArcadeSurfaceElevated,
              radius = 24.dp.toPx(),
              center = Offset(size.width / 2f, size.height / 2f),
            )
            // Top pointer
            val pointer = Path().apply {
              moveTo(size.width / 2f, 8.dp.toPx())
              lineTo(size.width / 2f - 10.dp.toPx(), -6.dp.toPx())
              lineTo(size.width / 2f + 10.dp.toPx(), -6.dp.toPx())
              close()
            }
            drawPath(pointer, color = Color.White)
          }
          Icon(
            imageVector = Icons.Rounded.Bolt,
            contentDescription = null,
            tint = GoldCoin,
            modifier = Modifier.size(26.dp),
          )
        }

        if (resultCoins != null) {
          Text(
            text = if (isBangla) "অভিনন্দন! +$resultCoins কুইককয়েন জিতেছেন!" else "You won +$resultCoins QuickCoins!",
            style = MaterialTheme.typography.titleMedium,
            color = EmeraldAccent,
          )
        } else {
          Text(
            text = if (isBangla) "স্পিন করতে ২৫ কয়েন লাগবে (পুরস্কার ১০–২০০ কয়েন)" else "Entry: 25 QuickCoins • Win 10 to 200 Coins",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (isSpinning || currentCoins < 25L) return@Button
          isSpinning = true
          resultCoins = null
          val winIdx = Random.nextInt(prizes.size)
          val wonAmount = prizes[winIdx]
          val sweep = 360f / prizes.size
          val targetAngle = rotation.value + 1440f + (360f - (winIdx * sweep + sweep / 2f))
          scope.launch {
            rotation.animateTo(
              targetValue = targetAngle,
              animationSpec = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            )
            isSpinning = false
            resultCoins = wonAmount
            onSpinWon(wonAmount)
          }
        },
        enabled = !isSpinning && currentCoins >= 25L,
        colors = ButtonDefaults.buttonColors(containerColor = GoldCoin, contentColor = Color(0xFF2B1D00)),
        modifier = Modifier.testTag("spin_wheel_confirm_button"),
      ) {
        Text(
          text = if (isSpinning) "..." else if (isBangla) "স্পিন (২৫)" else "Spin (25)",
          fontWeight = FontWeight.Bold,
        )
      }
    },
    dismissButton = {
      TextButton(onClick = { if (!isSpinning) onDismiss() }) {
        Text(if (isBangla) "বন্ধ করুন" else "Close")
      }
    },
  )
}
