package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.MiniGameId
import com.example.ui.theme.ArcadeBg
import com.example.ui.theme.ArcadeSurfaceBorder
import com.example.ui.theme.ArcadeSurfaceElevated
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.GoldCoin
import com.example.ui.theme.GoldWarm
import kotlinx.coroutines.delay

@Composable
fun MiniGamePlayScreen(
  game: MiniGameId,
  isBangla: Boolean,
  onRoundComplete: (score: Long, coinsEarned: Long, xpEarned: Long) -> Unit,
  onBack: () -> Unit,
) {
  BackHandler(onBack = onBack)

  var timeLeft by remember(game) { mutableIntStateOf(game.durationSec) }
  var currentScore by remember(game) { mutableIntStateOf(0) }
  var isFinished by remember(game) { mutableStateOf(false) }
  var roundKey by remember(game) { mutableIntStateOf(0) }
  var rewardsSaved by remember(game) { mutableStateOf(false) }

  LaunchedEffect(game, roundKey) {
    timeLeft = game.durationSec
    currentScore = 0
    isFinished = false
    rewardsSaved = false
    while (timeLeft > 0) {
      delay(1000L)
      timeLeft -= 1
    }
    isFinished = true
  }

  val coinsEarned = remember(isFinished, currentScore) {
    if (!isFinished) 0L else (40L + (currentScore / 4L)).coerceIn(40L, 500L)
  }
  val xpEarned = remember(isFinished, currentScore) {
    if (!isFinished) 0L else (25L + (currentScore / 6L)).coerceIn(25L, 400L)
  }

  LaunchedEffect(isFinished) {
    if (isFinished && !rewardsSaved) {
      rewardsSaved = true
      onRoundComplete(currentScore.toLong(), coinsEarned, xpEarned)
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(ArcadeBg)
      .safeDrawingPadding()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    // Top Play Bar
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onBack,
          modifier = Modifier.testTag("game_back_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = "Back",
            tint = MaterialTheme.colorScheme.onBackground,
          )
        }
        Text(
          text = if (isBangla) game.titleBn else game.titleEn,
          style = MaterialTheme.typography.titleLarge,
        )
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Surface(
          color = ArcadeSurfaceElevated,
          shape = RoundedCornerShape(50),
          modifier = Modifier.border(1.dp, ArcadeSurfaceBorder, RoundedCornerShape(50)),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
          ) {
            Icon(
              imageVector = Icons.Rounded.Timer,
              contentDescription = "Time Left",
              tint = if (timeLeft <= 5) CoralAlert else EmeraldAccent,
              modifier = Modifier.size(16.dp),
            )
            Text(
              text = "${timeLeft}s",
              style = MaterialTheme.typography.labelMedium,
              color = if (timeLeft <= 5) CoralAlert else MaterialTheme.colorScheme.onSurface,
            )
          }
        }

        Surface(
          color = MaterialTheme.colorScheme.secondaryContainer,
          shape = RoundedCornerShape(50),
        ) {
          Text(
            text = "Score: $currentScore",
            style = MaterialTheme.typography.labelMedium,
            color = GoldWarm,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          )
        }
      }
    }

    if (!isFinished) {
      Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
        when (game) {
          MiniGameId.REFLEX_TAP -> ReflexTapGame(
            isActive = !isFinished,
            onScoreChange = { currentScore = it },
          )
          MiniGameId.MEMORY_FLASH -> MemoryFlashGame(
            isActive = !isFinished,
            onScoreChange = { currentScore = it },
          )
          MiniGameId.COLOR_BLITZ -> ColorBlitzGame(
            isActive = !isFinished,
            onScoreChange = { currentScore = it },
          )
          MiniGameId.COIN_DASH -> CoinDashCanvasGame(
            isActive = !isFinished,
            onScoreChange = { currentScore = it },
          )
        }
      }
    } else {
      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth(),
        contentAlignment = Alignment.Center,
      ) {
        Surface(
          color = ArcadeSurfaceElevated,
          shape = RoundedCornerShape(24.dp),
          modifier = Modifier
            .fillMaxWidth()
            .border(1.5.dp, EmeraldAccent.copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            Icon(
              imageVector = Icons.Rounded.EmojiEvents,
              contentDescription = "Round Complete",
              tint = GoldCoin,
              modifier = Modifier.size(56.dp),
            )
            Text(
              text = if (isBangla) "রাউন্ড সম্পন্ন!" else "Round Complete!",
              style = MaterialTheme.typography.headlineMedium,
            )
            Text(
              text = if (isBangla) "স্কোর: $currentScore" else "Final Score: $currentScore",
              style = MaterialTheme.typography.titleLarge,
              color = EmeraldAccent,
            )
            Surface(
              color = MaterialTheme.colorScheme.secondaryContainer,
              shape = RoundedCornerShape(14.dp),
            ) {
              Text(
                text = "+$coinsEarned QuickCoins  •  +$xpEarned XP",
                style = MaterialTheme.typography.titleMedium,
                color = GoldWarm,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
              )
            }
            Spacer(Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              OutlinedButton(
                onClick = onBack,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f),
              ) {
                Text(if (isBangla) "অ্যারেনায় ফিরুন" else "Back to Hub")
              }
              Button(
                onClick = { roundKey += 1 },
                colors = ButtonDefaults.buttonColors(
                  containerColor = EmeraldAccent,
                  contentColor = MaterialTheme.colorScheme.onPrimary,
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                  .weight(1f)
                  .testTag("play_again_button"),
              ) {
                Text(
                  text = if (isBangla) "আবার খেলুন" else "Play Again",
                  fontWeight = FontWeight.Bold,
                )
              }
            }
          }
        }
      }
    }
  }
}
