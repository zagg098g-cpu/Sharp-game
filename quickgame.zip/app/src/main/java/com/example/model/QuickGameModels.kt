package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class UserProfile(
  @DocumentId val id: String = "",
  val userId: String = "",
  val displayName: String = "Player",
  val coins: Long = 500L,
  val xp: Long = 0L,
  val gamesPlayed: Long = 0L,
  val bestScore: Long = 0L,
  val streakDays: Long = 1L,
  val lastDailyClaimDate: String = "",
  val claimedMilestones: List<String> = emptyList(),
  val preferredLang: String = "en",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  val vipTier: String
    get() = computeTier(xp)

  companion object {
    fun computeTier(xp: Long): String = when {
      xp >= 2500L -> "Diamond"
      xp >= 1000L -> "Gold"
      xp >= 300L -> "Silver"
      else -> "Bronze"
    }
  }
}

@Keep
@IgnoreExtraProperties
data class GameSession(
  @DocumentId val id: String = "",
  val userId: String = "",
  val gameId: String = "",
  val gameTitle: String = "",
  val score: Long = 0L,
  val coinsEarned: Long = 0L,
  val xpEarned: Long = 0L,
  @ServerTimestamp val createdAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class LeaderboardEntry(
  @DocumentId val id: String = "",
  val userId: String = "",
  val displayName: String = "Player",
  val totalScore: Long = 0L,
  val coins: Long = 0L,
  val tier: String = "Bronze",
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

enum class MiniGameId(
  val id: String,
  val titleEn: String,
  val titleBn: String,
  val subtitleEn: String,
  val subtitleBn: String,
  val category: String,
  val rewardHint: String,
  val durationSec: Int,
) {
  REFLEX_TAP(
    id = "reflex_tap",
    titleEn = "Neon Reflex Tap",
    titleBn = "নিওন রিফ্লেক্স ট্যাপ",
    subtitleEn = "Tap glowing orbs fast for combo multipliers",
    subtitleBn = "দ্রুত গ্লোয়িং বল ট্যাপ করে কম্বো পয়েন্ট জিতুন",
    category = "Reflex",
    rewardHint = "+40–180 Coins",
    durationSec = 20,
  ),
  MEMORY_FLASH(
    id = "memory_flash",
    titleEn = "Memory Grid Flash",
    titleBn = "মেমোরি গ্রিড ফ্ল্যাশ",
    subtitleEn = "Repeat the neon tile sequence as rounds speed up",
    subtitleBn = "আলো জ্বলা টাইলসের ক্রম মনে রেখে ট্যাপ করুন",
    category = "Memory",
    rewardHint = "+50–220 Coins",
    durationSec = 45,
  ),
  COLOR_BLITZ(
    id = "color_blitz",
    titleEn = "Color Match Blitz",
    titleBn = "কালার ম্যাচ ব্লিটজ",
    subtitleEn = "Match the ink color, not the word, against the clock",
    subtitleBn = "লেখা নয়, রঙের সাথে মিল রেখে দ্রুত উত্তর দিন",
    category = "Puzzle",
    rewardHint = "+45–200 Coins",
    durationSec = 25,
  ),
  COIN_DASH(
    id = "coin_dash",
    titleEn = "Coin Catcher Dash",
    titleBn = "কয়েন ক্যাচার ড্যাশ",
    subtitleEn = "Slide the neon shield to catch coins & dodge hazards",
    subtitleBn = "শিল্ড সরিয়ে কয়েন ধরুন এবং লাল বোমা এড়ান",
    category = "Arcade",
    rewardHint = "+50–250 Coins",
    durationSec = 25,
  );

  companion object {
    fun fromId(raw: String): MiniGameId =
      entries.firstOrNull { it.id == raw } ?: REFLEX_TAP
  }
}

data class QuestMilestone(
  val id: String,
  val titleEn: String,
  val titleBn: String,
  val descEn: String,
  val descBn: String,
  val coinReward: Long,
  val xpReward: Long,
  val isEligible: (UserProfile) -> Boolean,
)

object QuickGameMilestones {
  val all = listOf(
    QuestMilestone(
      id = "first_game",
      titleEn = "First Spark",
      titleBn = "প্রথম ম্যাচ",
      descEn = "Complete your first mini-game round",
      descBn = "প্রথম যেকোনো মিনি-গেম রাউন্ড সম্পন্ন করুন",
      coinReward = 120L,
      xpReward = 50L,
      isEligible = { it.gamesPlayed >= 1L },
    ),
    QuestMilestone(
      id = "five_games",
      titleEn = "Arcade Regular",
      titleBn = "আর্কেড প্লেয়ার",
      descEn = "Play 5 total mini-game rounds",
      descBn = "মোট ৫টি মিনি-গেম রাউন্ড খেলুন",
      coinReward = 250L,
      xpReward = 120L,
      isEligible = { it.gamesPlayed >= 5L },
    ),
    QuestMilestone(
      id = "score_300",
      titleEn = "Sharp Shooter",
      titleBn = "শার্প স্কোরার",
      descEn = "Score 300+ points in any single round",
      descBn = "যেকোনো এক রাউন্ডে ৩০০+ স্কোর করুন",
      coinReward = 300L,
      xpReward = 150L,
      isEligible = { it.bestScore >= 300L },
    ),
    QuestMilestone(
      id = "coins_1500",
      titleEn = "Vault Collector",
      titleBn = "ভল্ট কালেক্টর",
      descEn = "Hold 1,500+ QuickCoins in your wallet",
      descBn = "ওয়ালেটে ১,৫০০+ কুইককয়েন সংগ্রহ করুন",
      coinReward = 400L,
      xpReward = 200L,
      isEligible = { it.coins >= 1500L },
    ),
  )
}

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>
  data class Success<T>(val data: T) : UiState<T>
  data class Error(val message: String) : UiState<Nothing>
}
