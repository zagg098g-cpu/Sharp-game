package com.example.data

import android.content.Context
import com.example.R
import com.example.model.GameSession
import com.example.model.LeaderboardEntry
import com.example.model.MiniGameId
import com.example.model.QuestMilestone
import com.example.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlin.math.max

class QuickGameRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
) {
  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    )
  )

  private fun requireMatchingUserId(expectedUid: String): String {
    val uid = auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    check(uid == expectedUid) { "Signed-in user changed; refusing cross-user write." }
    return uid
  }

  private fun sanitizeDisplayName(raw: String): String {
    val trimmed = raw.trim()
    return if (trimmed.isEmpty()) "QuickPlayer" else trimmed.take(60)
  }

  fun observeUserProfile(userId: String): Flow<UserProfile?> =
    db.collection("users").document(userId)
      .snapshots()
      .map { snapshot ->
        snapshot.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
      }

  fun observeRecentSessions(userId: String): Flow<List<GameSession>> =
    db.collection("users").document(userId).collection("sessions")
      .orderBy("createdAt", Query.Direction.DESCENDING)
      .limit(25)
      .snapshots()
      .map { snapshot ->
        snapshot.toObjects(GameSession::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
      }

  fun observeLeaderboard(): Flow<List<LeaderboardEntry>> =
    db.collection("leaderboard")
      .whereGreaterThanOrEqualTo("totalScore", 0L)
      .orderBy("totalScore", Query.Direction.DESCENDING)
      .limit(20)
      .snapshots()
      .map { snapshot ->
        snapshot.toObjects(LeaderboardEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
      }

  suspend fun ensureUserProfile(userId: String, initialDisplayName: String): Result<Unit> {
    val userPath = "users/$userId"
    return try {
      val uid = requireMatchingUserId(userId)
      val userRef = db.collection("users").document(uid)
      val userSnap = userRef.get().await()
      val safeName = sanitizeDisplayName(initialDisplayName)

      if (!userSnap.exists()) {
        val profilePayload = mapOf(
          "userId" to uid,
          "displayName" to safeName,
          "coins" to 500L,
          "xp" to 0L,
          "gamesPlayed" to 0L,
          "bestScore" to 0L,
          "streakDays" to 1L,
          "lastDailyClaimDate" to "",
          "claimedMilestones" to emptyList<String>(),
          "preferredLang" to "en",
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        userRef.set(profilePayload).await()
      }

      val lbRef = db.collection("leaderboard").document(uid)
      val lbSnap = lbRef.get().await()
      if (!lbSnap.exists()) {
        val currentProfile = userSnap.toObject(UserProfile::class.java)
        val initialXp = currentProfile?.xp ?: 0L
        val initialCoins = currentProfile?.coins ?: 500L
        val lbPayload = mapOf(
          "userId" to uid,
          "displayName" to (currentProfile?.displayName?.takeIf { it.isNotBlank() } ?: safeName),
          "totalScore" to initialXp,
          "coins" to initialCoins,
          "tier" to UserProfile.computeTier(initialXp),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
        lbRef.set(lbPayload).await()
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, userPath)
      Result.failure(e)
    }
  }

  suspend fun recordGameResult(
    userId: String,
    profile: UserProfile,
    game: MiniGameId,
    score: Long,
    coinsEarned: Long,
    xpEarned: Long,
  ): Result<Unit> {
    val userPath = "users/$userId"
    return try {
      val uid = requireMatchingUserId(userId)
      val safeScore = score.coerceIn(0L, 1_000_000L)
      val safeCoinsEarned = coinsEarned.coerceIn(0L, 50_000L)
      val safeXpEarned = xpEarned.coerceIn(0L, 50_000L)

      val newCoins = (profile.coins + safeCoinsEarned).coerceAtMost(100_000_000L)
      val newXp = (profile.xp + safeXpEarned).coerceAtMost(100_000_000L)
      val newGames = (profile.gamesPlayed + 1L).coerceAtMost(1_000_000L)
      val newBest = max(profile.bestScore, safeScore).coerceAtMost(10_000_000L)

      val sessionRef = db.collection("users").document(uid).collection("sessions").document()
      val sessionPayload = mapOf(
        "userId" to uid,
        "gameId" to game.id,
        "gameTitle" to game.titleEn.take(60),
        "score" to safeScore,
        "coinsEarned" to safeCoinsEarned,
        "xpEarned" to safeXpEarned,
        "createdAt" to FieldValue.serverTimestamp(),
      )
      sessionRef.set(sessionPayload).await()

      db.collection("users").document(uid).update(
        mapOf(
          "coins" to newCoins,
          "xp" to newXp,
          "gamesPlayed" to newGames,
          "bestScore" to newBest,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()

      syncLeaderboard(uid, profile.displayName, newXp, newCoins)
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, userPath)
      Result.failure(e)
    }
  }

  suspend fun claimDailyBonus(
    userId: String,
    profile: UserProfile,
    todayKey: String,
  ): Result<Long> {
    val userPath = "users/$userId"
    return try {
      val uid = requireMatchingUserId(userId)
      require(profile.lastDailyClaimDate != todayKey) { "Daily bonus already claimed today." }
      val nextStreak = if (profile.lastDailyClaimDate.isBlank()) 1L else (profile.streakDays + 1L).coerceAtMost(36500L)
      val bonusCoins = (100L + (nextStreak - 1L) * 25L).coerceAtMost(500L)
      val newCoins = (profile.coins + bonusCoins).coerceAtMost(100_000_000L)
      val newXp = (profile.xp + 50L).coerceAtMost(100_000_000L)

      db.collection("users").document(uid).update(
        mapOf(
          "coins" to newCoins,
          "xp" to newXp,
          "streakDays" to nextStreak,
          "lastDailyClaimDate" to todayKey.take(20),
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()

      syncLeaderboard(uid, profile.displayName, newXp, newCoins)
      Result.success(bonusCoins)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, userPath)
      Result.failure(e)
    }
  }

  suspend fun spinLuckyWheel(
    userId: String,
    profile: UserProfile,
    costCoins: Long,
    rewardCoins: Long,
  ): Result<Long> {
    val userPath = "users/$userId"
    return try {
      val uid = requireMatchingUserId(userId)
      require(profile.coins >= costCoins) { "Not enough QuickCoins to spin." }
      val newCoins = (profile.coins - costCoins + rewardCoins).coerceIn(0L, 100_000_000L)
      val newXp = (profile.xp + 15L).coerceAtMost(100_000_000L)

      db.collection("users").document(uid).update(
        mapOf(
          "coins" to newCoins,
          "xp" to newXp,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()

      syncLeaderboard(uid, profile.displayName, newXp, newCoins)
      Result.success(rewardCoins)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, userPath)
      Result.failure(e)
    }
  }

  suspend fun claimMilestone(
    userId: String,
    profile: UserProfile,
    milestone: QuestMilestone,
  ): Result<Unit> {
    val userPath = "users/$userId"
    return try {
      val uid = requireMatchingUserId(userId)
      require(!profile.claimedMilestones.contains(milestone.id)) { "Milestone already claimed." }
      require(milestone.isEligible(profile)) { "Milestone requirements not yet met." }
      require(profile.claimedMilestones.size < 20) { "Milestone limit reached." }

      val updatedList = (profile.claimedMilestones + milestone.id).distinct().take(20)
      val newCoins = (profile.coins + milestone.coinReward).coerceAtMost(100_000_000L)
      val newXp = (profile.xp + milestone.xpReward).coerceAtMost(100_000_000L)

      db.collection("users").document(uid).update(
        mapOf(
          "coins" to newCoins,
          "xp" to newXp,
          "claimedMilestones" to updatedList,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()

      syncLeaderboard(uid, profile.displayName, newXp, newCoins)
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, userPath)
      Result.failure(e)
    }
  }

  suspend fun updateProfileSettings(
    userId: String,
    displayName: String,
    preferredLang: String,
    profile: UserProfile,
  ): Result<Unit> {
    val userPath = "users/$userId"
    return try {
      val uid = requireMatchingUserId(userId)
      val safeName = sanitizeDisplayName(displayName)
      val safeLang = if (preferredLang == "bn") "bn" else "en"

      db.collection("users").document(uid).update(
        mapOf(
          "displayName" to safeName,
          "preferredLang" to safeLang,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()

      syncLeaderboard(uid, safeName, profile.xp, profile.coins)
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, userPath)
      Result.failure(e)
    }
  }

  private suspend fun syncLeaderboard(
    uid: String,
    displayName: String,
    xp: Long,
    coins: Long,
  ) {
    val lbRef = db.collection("leaderboard").document(uid)
    val safeName = sanitizeDisplayName(displayName)
    val safeXp = xp.coerceIn(0L, 100_000_000L)
    val safeCoins = coins.coerceIn(0L, 100_000_000L)
    val tier = UserProfile.computeTier(safeXp)

    val existingSnap = lbRef.get().await()
    if (existingSnap.exists()) {
      lbRef.update(
        mapOf(
          "displayName" to safeName,
          "totalScore" to safeXp,
          "coins" to safeCoins,
          "tier" to tier,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    } else {
      lbRef.set(
        mapOf(
          "userId" to uid,
          "displayName" to safeName,
          "totalScore" to safeXp,
          "coins" to safeCoins,
          "tier" to tier,
          "updatedAt" to FieldValue.serverTimestamp(),
        )
      ).await()
    }
  }
}
